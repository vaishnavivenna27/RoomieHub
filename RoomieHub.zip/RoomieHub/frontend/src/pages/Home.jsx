import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import '../css/Home.css';

const Home = () => {
  const { isAuthenticated } = useAuth();

  const features = [
    {
      title: 'Smart Expense Splitting',
      description: 'Log rent, utilities, and groceries. Split costs evenly across roommates automatically without manual math.',
      icon: '💸'
    },
    {
      title: 'Payment & Debt Tracking',
      description: 'Know instantly who paid, who owes money, and settle balances in a single click.',
      icon: '📊'
    },
    {
      title: 'Household Chore Rotation',
      description: 'Assign cleaning, trash, and kitchen duties with due dates to keep your home spotless and fair.',
      icon: '🧹'
    },
    {
      title: 'Shared Grocery Checklist',
      description: 'Collaborative shopping lists where anyone can add needed items and mark them purchased.',
      icon: '🛒'
    },
    {
      title: 'Room Notice Board',
      description: 'Post important apartment rules, maintenance notices, and guest plans for everyone to see.',
      icon: '📢'
    },
    {
      title: 'Monthly Spending Reports',
      description: 'Visual category-wise breakdown and individual roommate spending analytics at your fingertips.',
      icon: '📈'
    }
  ];

  return (
    <div className="home-page">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-content">
          <div className="hero-badge">
            <span className="badge badge-purple">✨ The Ultimate Roommate App</span>
          </div>
          <h1 className="hero-title">
            Shared Living, <span className="hero-accent">Simplified.</span>
          </h1>
          <p className="hero-description">
            RoomieHub is the modern platform that helps roommates coordinate rent, split bills, assign household chores, manage grocery shopping, and share important house notices in one place.
          </p>

          <div className="hero-actions">
            {isAuthenticated ? (
              <Link to="/dashboard" className="btn btn-lg btn-primary">
                Open Dashboard ➔
              </Link>
            ) : (
              <>
                <Link to="/register" className="btn btn-lg btn-primary">
                  Get Started Free
                </Link>
                <Link to="/features" className="btn btn-lg btn-outline">
                  Explore Features
                </Link>
              </>
            )}
          </div>

          <div className="hero-stats-bar">
            <div className="stat-item">
              <span className="stat-number">100%</span>
              <span className="stat-label">Transparent Splitting</span>
            </div>
            <div className="stat-divider"></div>
            <div className="stat-item">
              <span className="stat-number">0</span>
              <span className="stat-label">Roommate Arguments</span>
            </div>
            <div className="stat-divider"></div>
            <div className="stat-item">
              <span className="stat-number">6+</span>
              <span className="stat-label">Integrated Tools</span>
            </div>
          </div>
        </div>
      </section>

      {/* Six Feature Cards Section */}
      <section className="features-section">
        <div className="section-header">
          <span className="section-eyebrow">FEATURES</span>
          <h2 className="section-title">Everything You Need for a Peaceful Home</h2>
          <p className="section-subtitle">
            Say goodbye to awkward money chats and forgotten chore charts. RoomieHub covers every aspect of shared living.
          </p>
        </div>

        <div className="features-grid">
          {features.map((feat, index) => (
            <div key={index} className="feature-card">
              <div className="feature-icon">{feat.icon}</div>
              <h3 className="feature-card-title">{feat.title}</h3>
              <p className="feature-card-description">{feat.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* About RoomieHub Section */}
      <section className="home-about-section">
        <div className="about-banner card">
          <div className="about-text-content">
            <span className="badge badge-purple">CAPSTONE PROJECT</span>
            <h2 className="about-banner-title">Why RoomieHub Was Created</h2>
            <p className="about-banner-desc">
              Living with roommates can be fantastic, but tracking receipts, splitting Wi-Fi bills, and reminding people about chores often causes friction. RoomieHub transforms communal chaos into transparent, stress-free living through automated tracking, shared lists, and accountability.
            </p>
            <div className="about-banner-actions">
              <Link to="/about" className="btn btn-primary">
                Read Our Story ➔
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Final Call to Action */}
      <section className="cta-section">
        <div className="cta-container">
          <h2 className="cta-title">Ready to Upgrade Your Living Experience?</h2>
          <p className="cta-desc">
            Create a room, invite your roommates with your 6-digit room code, and start managing your home with ease.
          </p>
          <Link to="/register" className="btn btn-lg btn-primary">
            Join RoomieHub Today
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;
