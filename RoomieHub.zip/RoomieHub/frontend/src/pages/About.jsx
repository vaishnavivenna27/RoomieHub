import React from 'react';
import { Link } from 'react-router-dom';
import '../css/About.css';

const About = () => {
  return (
    <div className="about-page">
      <div className="about-header">
        <span className="badge badge-purple">CAPSTONE PROJECT</span>
        <h1 className="about-title">About RoomieHub</h1>
        <p className="about-subtitle">
          Building a smarter, more harmonious living experience for roommates everywhere.
        </p>
      </div>

      <div className="about-grid">
        {/* The Problem */}
        <div className="card about-card">
          <div className="about-card-icon">⚠️</div>
          <h2>The Problem</h2>
          <p>
            Communal living with roommates often leads to awkward conflicts:
          </p>
          <ul className="about-list">
            <li>Forgetting who paid for WiFi, electricity, or toilet paper.</li>
            <li>Uneven chore distribution leading to resentment.</li>
            <li>Duplicate grocery purchases or forgetting essentials.</li>
            <li>Lost messages and disorganized group chat reminders.</li>
          </ul>
        </div>

        {/* The Solution */}
        <div className="card about-card highlight-card">
          <div className="about-card-icon">💡</div>
          <h2>The Solution: RoomieHub</h2>
          <p>
            RoomieHub provides a centralized, transparent dashboard designed specifically for flatmates.
          </p>
          <ul className="about-list">
            <li>Automatic equal split calculation for expenses.</li>
            <li>Real-time payment and debt tracking with instant settlement.</li>
            <li>Household chores rotation with scheduled due dates.</li>
            <li>Interactive shared grocery shopping list.</li>
            <li>Room-wide digital bulletin board for important notices.</li>
          </ul>
        </div>
      </div>

      {/* Tech Architecture */}
      <div className="card tech-architecture-card">
        <h2>🛠️ Architecture & Technology Stack</h2>
        <p className="tech-desc">
          RoomieHub is engineered as a clean, performant, and beginner-friendly full-stack MERN application.
        </p>

        <div className="tech-stack-grid">
          <div className="tech-box">
            <h4>Frontend</h4>
            <ul>
              <li><strong>React.js (Vite):</strong> Fast component-based user interface.</li>
              <li><strong>React Router DOM:</strong> Single Page Application client routing.</li>
              <li><strong>Vanilla CSS:</strong> Modular, scoped stylesheets without heavy CSS frameworks.</li>
              <li><strong>Native Fetch API:</strong> Standardized REST calls without third-party bloat.</li>
            </ul>
          </div>

          <div className="tech-box">
            <h4>Backend & Database</h4>
            <ul>
              <li><strong>Node.js & Express.js:</strong> Scalable RESTful API backend.</li>
              <li><strong>JWT Authentication:</strong> Secure token-based session handling.</li>
              <li><strong>bcrypt.js:</strong> Military-grade password salting and hashing.</li>
              <li><strong>MongoDB & Mongoose:</strong> Document-based schemas with strict ObjectId relationships.</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Call to action */}
      <div className="about-cta">
        <h3>Ready to experience seamless shared living?</h3>
        <Link to="/register" className="btn btn-primary btn-lg">
          Create Your Room Now ➔
        </Link>
      </div>
    </div>
  );
};

export default About;
