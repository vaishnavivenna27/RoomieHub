import React from 'react';
import { Link } from 'react-router-dom';
import '../css/Features.css';

const Features = () => {
  const featureList = [
    {
      title: '1. Room Management with 6-Digit Codes',
      icon: '🏠',
      summary: 'Easily set up your apartment and invite flatmates.',
      details: [
        'Instantly generate a private, secure 6-character alphanumeric room code.',
        'Roommates join immediately using your code—no complicated invites needed.',
        'View all roommates in one centralized list with creator roles.'
      ]
    },
    {
      title: '2. Automatic Equal Expense Splitting',
      icon: '💸',
      summary: 'No more calculators, spreadsheets, or guesswork.',
      details: [
        'Log expenses with title, amount, category, and date.',
        'Choose whether to split equally with all room members or specific roommates.',
        'Automatically creates debt tracking balances for every participant.',
        'Edit or delete logged expenses with real-time balance updates.'
      ]
    },
    {
      title: '3. Transparent Payment Tracking',
      icon: '💳',
      summary: 'Clear breakdown of who owes what and one-click settlements.',
      details: [
        'See your personalized summary: Amount you owe vs. Amount owed to you.',
        'Detailed payment list with status tags (Pending vs. Paid).',
        'Mark debts as paid once settled via cash or payment apps.'
      ]
    },
    {
      title: '4. Household Chore Rotation & Schedule',
      icon: '🧹',
      summary: 'Keep living spaces clean without awkward reminders.',
      details: [
        'Assign tasks like kitchen cleaning, bathroom duty, taking out trash, and vacuuming.',
        'Set firm due dates and monitor pending tasks.',
        'Roommates can mark tasks completed with a single tap.'
      ]
    },
    {
      title: '5. Shared Grocery Shopping List',
      icon: '🛒',
      summary: 'Never forget essentials like milk, dish soap, or snacks.',
      details: [
        'Add items with required quantities and categories (Produce, Dairy, Cleaning, etc.).',
        'Check off items as they are purchased during your shopping trip.',
        'Delete items that are no longer needed.'
      ]
    },
    {
      title: '6. Room Announcement Bulletin Board',
      icon: '📢',
      summary: 'Broadcast important house notices in a permanent feed.',
      details: [
        'Post landlord visits, party notices, guest policies, or maintenance alerts.',
        'Author attribution and posting timestamps.',
        'Protected authorization: only the author can edit or delete their notices.'
      ]
    },
    {
      title: '7. Reports & Monthly Analytics',
      icon: '📊',
      summary: 'Clear visualization of where house money is spent.',
      details: [
        'Monthly spending totals aggregated across bills.',
        'Category breakdown charts showing percentage of spend on Rent, Utilities, Food, etc.',
        'Roommate-wise spending contributions and debt breakdown.'
      ]
    }
  ];

  return (
    <div className="features-page">
      <div className="features-header">
        <span className="badge badge-purple">FUNCTIONALITY OVERVIEW</span>
        <h1 className="features-title">Designed for Everyday Flatmate Life</h1>
        <p className="features-subtitle">
          Every tool inside RoomieHub is purpose-built to solve common roommate frictions and keep your household organized.
        </p>
      </div>

      <div className="features-detail-grid">
        {featureList.map((feat, index) => (
          <div key={index} className="card feature-detail-card">
            <div className="feature-card-top">
              <span className="feature-big-icon">{feat.icon}</span>
              <div>
                <h2 className="feature-title">{feat.title}</h2>
                <p className="feature-summary">{feat.summary}</p>
              </div>
            </div>

            <div className="feature-bullets">
              {feat.details.map((point, idx) => (
                <div key={idx} className="feature-bullet-item">
                  <span className="bullet-check">✓</span>
                  <span>{point}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="features-cta-box card">
        <h2>Start organizing your shared apartment today</h2>
        <p>Simple setup in under 60 seconds. Free for all roommates.</p>
        <Link to="/register" className="btn btn-primary btn-lg">
          Create Free Account ➔
        </Link>
      </div>
    </div>
  );
};

export default Features;
